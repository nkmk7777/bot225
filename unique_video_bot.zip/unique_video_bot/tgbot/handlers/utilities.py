import json
import time
import subprocess
import asyncio
from PIL import Image, ImageDraw, ImageFont
import random
import os
import zipfile
import rarfile
import mimetypes
import ffmpeg
import numpy as np
from pydub.generators import WhiteNoise
import functools 

from aiogram import Router, F
from aiogram.filters import CommandStart, Filter, Command
from aiogram.types import Message, FSInputFile
from aiogram.enums.content_type import ContentType
from aiogram.enums.parse_mode import ParseMode

from tgbot.config import load_channel
from infrastructure.database.repo.requests import user_is_registered, create_user



channel_id = load_channel(".env")


def check_user_folder(username, current_dir):
    folder_path = f"{current_dir}/files/{username}"
    if not os.path.exists(folder_path):
        os.mkdir(folder_path)

def archive_exctractor_run(save_path, origin_file_name):
    origin_file_path = f"{save_path}/{origin_file_name}"
    files = []
    if origin_file_name.endswith(".zip"):
        with zipfile.ZipFile(origin_file_path, "r") as zip_ref:
            print(zip_ref.namelist())
            i = 1
            for file_name in zip_ref.namelist():
                i += 1
                mimestart = mimetypes.guess_type(file_name)[0]
                if mimestart.split('/')[0] in ('video', 'image'):
                    with zip_ref.open(file_name) as file:
                        check = mimetypes.guess_type(save_path)[0]
                        if isinstance(check, type(None)):
                            save_path = os.path.join(save_path, f"{os.path.splitext(os.path.basename(origin_file_path))[0]}_{file_name}")
                        else:
                            if save_path == save_path:
                                # files/username/out
                                parts = save_path.split("/")
                                parts[-1] = f"{i}_{parts[-1]}"
                                save_path = "/".join(parts)
                        print(save_path)
                        # save_path = f"{save_path}/{file_name}"
                        with open(save_path, 'wb') as outfile:
                            outfile.write(file.read())
                        files.append(save_path.split("/")[-1])
            print(files)
            os.remove(origin_file_path)
        return files

            
    elif origin_file_name.endswith(".rar"):
        with rarfile.RarFile(origin_file_path, "r") as rar_ref:
            for file_name in rar_ref.namelist():
                mimestart = mimetypes.guess_type(file_name)[0]
                if mimestart.split('/')[0] in ('video', 'image'):
                    with rar_ref.open(file_name) as file:
                        save_path = os.path.join(save_path, f"{os.path.splitext(os.path.basename(origin_file_path))[0]}_{file_name}")
                        with open(save_path, 'wb') as outfile:
                            outfile.write(file.read())
                        files.append(f"{os.path.splitext(os.path.basename(origin_file_path))[0]}_{file_name}")
            os.remove(origin_file_path)
        return files


async def save_file(bot, file_path, save_path, file_name):
    if not os.path.exists(save_path):
        os.makedirs(save_path)
    await bot.download_file(file_path, f"{save_path}/{file_name}")

def generate_random_image_run(width, height, output_file):
    num_shapes = random.randint(5,11)
    image = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(image)

    for _ in range(num_shapes):
        shape_type = random.choice(["rectangle", "ellipse"])
        color = (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))
        x0 = random.randint(0, width)
        y0 = random.randint(0, height)
        x1 = random.randint(x0, width)
        y1 = random.randint(y0, height)
        if shape_type == "rectangle":
            draw.rectangle([x0, y0, x1, y1], fill=color)
        elif shape_type == "ellipse":
            draw.ellipse([x0, y0, x1, y1], fill=color)

    image.save(output_file)
    print(f"Random image generated and saved as '{output_file}'.")

def generate_random_noise_run(output_file, duration=5):
    white_noise = WhiteNoise().to_audio_segment(duration=duration*1000)
    white_noise.export(output_file, format="wav")

def add_metadata_run(image_path, metadata):
    # Открываем изображение
    image = Image.open(image_path)

    # Получаем текущие метаданные изображения
    exif_data = image.info.get("exif", b"")
    exif_str = exif_data.decode("utf-8") if isinstance(exif_data, bytes) else ""

    # Обновляем метаданные, добавляя новые или обновляя существующие значения
    exif_str += "\n".join([f"{key}: {value}" for key, value in metadata.items()])

    # Сохраняем изображение с обновленными метаданными
    image.save(image_path, exif=exif_str.encode("utf-8"))

def generate_unique_text_run():
    # Генерация случайной строки
    return ''.join(random.choices('abcdefghijklmnopqrstuvwxyz0123456789', k=20))

def add_unique_invisible_layer_run(image_path, output_path):
    # Открытие изображения
    with Image.open(image_path) as img:
        # Создание "невидимого" слоя
        invisible_layer = Image.new('RGBA', img.size, (255, 255, 255, 0))
        draw = ImageDraw.Draw(invisible_layer)

        # Создание уникального текста
        unique_text = generate_unique_text_run()
        # Если у вас есть шрифт, вы можете использовать его
        # font = ImageFont.truetype('path/to/font.ttf', size=12)
        draw.text((10, 10), unique_text, fill=(255, 255, 255, 0))  # , font=font

        # Совмещение изображения с невидимым слоем
        combined = Image.alpha_composite(img.convert('RGBA'), invisible_layer)

        # Сохранение результата
        combined.save(output_path, quality=95)  # Сохранение с высоким качеством

def add_video_size_run(input_size, output_size, output_file):
    unique_data = b"0"
    if output_size <= input_size:
        mb = 1*1024*1024
        add_bytes = input_size - output_size + mb
        
        with open(output_file, "ab") as f:
            f.write(b"\0" * add_bytes)

def overlay_images_run(background_path, overlay_path, output_path):
    background = Image.open(background_path)
    overlay = Image.open(overlay_path)

    background = background.convert('RGB')
    overlay = overlay.convert('RGB')

    if background.size != overlay.size:
        overlay = overlay.resize(background.size)

    blended = Image.blend(background, overlay, alpha=0.0001)
    blended.save(output_path, quality=99)

    input_image_size = os.path.getsize(background_path)
    output_image_size = os.path.getsize(output_path)
    target_size = input_image_size + 1024 * 1024  # размер выходного файла на 1 МБ больше входного
    add_video_size_run(input_image_size, output_image_size, output_path)

def get_length_run(filename):
    result = subprocess.run(['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'json', filename], capture_output=True)
    if result.returncode == 0:
        data = json.loads(result.stdout.decode('utf-8'))
        return float(data['format']['duration'])
    else:
        return None

def get_video_audio_bitrates_run(video_file):
    probe = ffmpeg.probe(video_file)
    video_stream = next((stream for stream in probe['streams'] if stream['codec_type'] == 'video'), None)
    audio_stream = next((stream for stream in probe['streams'] if stream['codec_type'] == 'audio'), None)

    video_bitrate = int(video_stream['bit_rate']) if video_stream else None
    audio_bitrate = int(audio_stream['bit_rate']) if audio_stream else None

    return video_bitrate, audio_bitrate
        
def create_unique_video_run(input_file, output_file, input_overlay, input_sound_overlay):
    input_file_size = os.path.getsize(input_file)
    video_bitrate, audio_bitrate = get_video_audio_bitrates_run(input_file)
    video_length = get_length_run(input_file)

    rand_img = generate_random_image_run(1000, 1000, input_overlay)
    generate_random_noise_run(input_sound_overlay, int(video_length))

    subprocess.run(f"""ffmpeg -i {input_file} -i {input_overlay} -i {input_sound_overlay} \
                        -filter_complex "[1:v]format=argb,geq=r='r(X,Y)':a='0*alpha(X,Y)'[zork]; [0:v][zork]overlay[v]; \
                        [0:a]volume=1.0[a]; [2]volume=0[b];[a][b]amix=2:shortest[a]" \
                        -map "[v]" -map "[a]" -c:v libx264 -crf 19 -b:v {video_bitrate/1000}k \
                        -c:a aac -b:a {audio_bitrate/1000}k -map_metadata:g -1 -map_metadata:s:v -1 \
                        -map_metadata:s:a -1 -map_chapters -1 -threads 4 {output_file}""", shell=True)

    output_file_size = os.path.getsize(output_file)
    add_video_size_run(input_file_size, output_file_size, output_file)

def create_zip_run(file_list, zip_name):
    with zipfile.ZipFile(zip_name, 'w') as zipf:
        for file in file_list:
            zipf.write(file, os.path.basename(file))

async def create_zip(file_list, zip_name):
    loop = asyncio.get_event_loop()
    result = await loop.run_in_executor(None, functools.partial(create_zip_run, file_list=file_list, zip_name=zip_name))
    return result

async def create_unique_video(input_file, output_file, input_overlay, input_sound_overlay):
    loop = asyncio.get_event_loop()
    result = await loop.run_in_executor(None, functools.partial(create_unique_video_run, input_file=input_file, output_file=output_file, input_overlay=input_overlay, input_sound_overlay=input_sound_overlay))
    return result

async def get_video_audio_bitrates(video_file):
    loop = asyncio.get_event_loop()
    result = await loop.run_in_executor(None, functools.partial(get_video_audio_bitrates_run, video_file=video_file))
    return result

async def get_length(filename):
    loop = asyncio.get_event_loop()
    result = await loop.run_in_executor(None, functools.partial(get_length_run, filename=filename))
    return result

async def overlay_images(background_path, overlay_path, output_path):
    loop = asyncio.get_event_loop()
    result = await loop.run_in_executor(None, functools.partial(overlay_images_run, background_path=background_path, overlay_path=overlay_path, output_path=output_path))
    return result

async def overlay_images(background_path, overlay_path, output_path):
    loop = asyncio.get_event_loop()
    result = await loop.run_in_executor(None, functools.partial(overlay_images_run, background_path=background_path, overlay_path=overlay_path, output_path=output_path))
    return result

async def add_video_size(input_size, output_size, output_file):
    loop = asyncio.get_event_loop()
    result = await loop.run_in_executor(None, functools.partial(add_video_size_run, input_size=input_size, output_size=output_size, output_file=output_file))
    return result

async def add_unique_invisible_layer(image_path, metadata):
    loop = asyncio.get_event_loop()
    result = await loop.run_in_executor(None, functools.partial(add_unique_invisible_layer_run, image_path=image_path, metadata=metadata))
    return result

async def generate_unique_text():
    loop = asyncio.get_event_loop()
    result = await loop.run_in_executor(None, functools.partial(generate_unique_text_run))
    return result

async def add_metadata(image_path, metadata):
    loop = asyncio.get_event_loop()
    result = await loop.run_in_executor(None, functools.partial(add_metadata_run, image_path=image_path, metadata=metadata))
    return result

async def generate_random_noise(output_file, duration=5):
    loop = asyncio.get_event_loop()
    result = await loop.run_in_executor(None, functools.partial(generate_random_noise_run, output_file=output_file, duration=duration))
    return result

async def generate_random_image(width, height, output_file):
    loop = asyncio.get_event_loop()
    result = await loop.run_in_executor(None, functools.partial(generate_random_image_run, width=width, height=height, output_file=output_file))
    return result

async def archive_exctractor(save_path, origin_file_name):
    loop = asyncio.get_event_loop()
    result = await loop.run_in_executor(None, functools.partial(archive_exctractor_run, save_path=save_path, origin_file_name=origin_file_name))
    return result